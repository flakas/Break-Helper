Break Helper
------------

[Break Helper on Chrome Webstore](https://chrome.google.com/webstore/detail/dllmmaniogaffdnagcenlnnlbahmlmld)
This is a Chrome extension that periodically reminds you to take a break.

Notification sound credits: _Notification Sounds (notificationsounds.com)_
